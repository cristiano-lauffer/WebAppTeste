﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using Newtonsoft.Json;

namespace WebAppTeste.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View();
        }

        public async Task<IActionResult> Teste()
        {
            Dictionary<string, string> dados = new Dictionary<string, string>();

            using (var httpClient = new HttpClient())
            {
                var json = await httpClient.GetStringAsync("http://www.portoalegrelivre.com.br/php/services/WSPoaLivreRedes.php");

                JsonTextReader reader = new JsonTextReader(new System.IO.StringReader(json));
                while (reader.Read())
                {
                    if (reader.Value != null)
                    {
                        //Console.WriteLine("Token: {0}, Value: {1}", reader.TokenType, reader.Value);
                        dados.Add(reader.TokenType.ToString(), reader.Value.ToString());
                    }
                    else
                    {
                        //Console.WriteLine("Token: {0}", reader.TokenType);
                    }
                }
            }

            return View(dados);
        }
    }
}
